# Pear Desktop – Liquid Glass Theme

A custom Liquid Glass UI theme for Pear Desktop, inspired by modern iOS-style transparency and blur effects.

## Author
Chamod Yoshitha Dissanayaka

## Version
1.0.0

## Requirements
- Pear Desktop
- Custom CSS support enabled

---

## Installation Instructions

1. Open "Pear Desktop"
2. Click the "Options" menu (top left)
3. Go to "Visual Tweaks"
4. Open "Themes"
5. Select "Import Custom CSS"
6. Choose the provided "theme.css" file
7. Apply and restart Pear Desktop if required

---

## Notes
- This theme is optimized for default Pear Desktop layouts
- Best visual results with transparency enabled
- Performance impact is minimal on modern systems

---

## License
This theme is licensed for personal use only.

- Redistribution is not allowed
- Modification and re-uploading is not allowed
- Removal of author credit is prohibited

See `LICENSE.txt` for full terms.

---

© 2025 Chamod. All rights reserved.
